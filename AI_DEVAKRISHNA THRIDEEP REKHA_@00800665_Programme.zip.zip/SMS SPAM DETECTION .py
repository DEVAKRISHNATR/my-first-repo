import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.metrics import classification_report, accuracy_score, precision_score, recall_score, f1_score
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import GridSearchCV
from twilio.rest import Client
import os
import tkinter as tk
from tkinter import filedialog, messagebox, Text


class SpamDetectionSystem:
    """A system for detecting spam messages and sending alerts via WhatsApp."""

    # Twilio configuration - you would replace these with your actual credentials
    TWILIO_ACCOUNT_SID = "ACf6fe008ac616740b6639b9cb968c16f3"
    TWILIO_AUTH_TOKEN = "1f91e71b14f750469225f34bdda9f388"
    TWILIO_WHATSAPP_NUMBER = "whatsapp:+14155238886"  # Twilio sandbox WhatsApp number
    RECIPIENT_WHATSAPP_NUMBER = "whatsapp:+919061899190"  # Your verified WhatsApp number

    def __init__(self):
        """Initialize the spam detection system."""
        self.dataset = None
        self.vectorizer = None
        self.trained_model = None
        self.model_parameters = None

    def send_spam_alert(self, message_content):
        """
        Send a WhatsApp alert when spam is detected.

        Args:
            message_content: The spam message content to report
        """
        twilio_client = Client(self.TWILIO_ACCOUNT_SID, self.TWILIO_AUTH_TOKEN)
        try:
            whatsapp_message = twilio_client.messages.create(
                body=f"🚨 SPAM ALERT: '{message_content}'",
                from_=self.TWILIO_WHATSAPP_NUMBER,
                to=self.RECIPIENT_WHATSAPP_NUMBER
            )
            messagebox.showinfo(
                "WhatsApp Alert Sent",
                f"Spam alert successfully delivered!\nMessage ID: {whatsapp_message.sid}"
            )
        except Exception as error:
            messagebox.showerror(
                "Alert Delivery Failed",
                f"Could not send WhatsApp alert. Error details:\n{error}"
            )

    def clean_dataset(self, dataset):
        """
        Clean and prepare the dataset for training.

        Args:
            dataset: Raw dataset with 'label' and 'message' columns

        Returns:
            Cleaned dataset ready for training
        """
        # Remove rows with missing values
        clean_data = dataset.dropna()

        # Convert text labels to numerical values (ham=0, spam=1)
        clean_data['label'] = clean_data['label'].map({'ham': 0, 'spam': 1})

        return clean_data

    def create_text_features(self, message_data):
        """
        Convert text messages into numerical features using bag-of-words.

        Args:
            message_data: DataFrame containing the messages to vectorize

        Returns:
            Feature matrix and the fitted vectorizer
        """
        # Create a vectorizer that ignores common English words and limits features
        text_vectorizer = CountVectorizer(
            stop_words="english",  # Remove common words like "the", "and", etc.
            max_features=3000  # Limit to 3000 most common words
        )

        # Transform the text messages into a numerical matrix
        feature_matrix = text_vectorizer.fit_transform(message_data['message']).toarray()

        return feature_matrix, text_vectorizer

    def build_optimized_model(self, training_features, test_features, training_labels, test_labels, model_type):
        """
        Train and optimize a machine learning model for spam detection.

        Args:
            training_features: Features for training
            test_features: Features for testing
            training_labels: Labels for training
            test_labels: Labels for testing
            model_type: Type of model to train ("Logistic Regression" or "Random Forest")

        Returns:
            Tuple containing (best model, best parameters, accuracy, precision, recall, f1 score, classification report)
        """
        try:
            # Configure different hyperparameter options based on model type
            if model_type == "Logistic Regression":
                search_parameters = {
                    'C': [0.1, 1, 10],  # Regularization strength
                    'solver': ['liblinear', 'lbfgs']  # Optimization algorithms
                }
                base_model = LogisticRegression(max_iter=1000)

            elif model_type == "Random Forest":
                search_parameters = {
                    'n_estimators': [50, 100],  # Number of trees in the forest
                    'max_depth': [10, 20],  # Maximum depth of trees
                    'min_samples_split': [2, 5]  # Minimum samples required to split a node
                }
                base_model = RandomForestClassifier(random_state=42)

            else:
                messagebox.showerror("Invalid Selection", f"Model type '{model_type}' is not supported.")
                return None, None, 0, 0, 0, 0, ""

            # Show training progress notification
            messagebox.showinfo(
                "Training in Progress",
                "Building and optimizing your spam detection model...\nThis might take a minute, please wait."
            )

            # Perform grid search to find the best hyperparameters
            parameter_search = GridSearchCV(
                base_model,
                search_parameters,
                cv=3,  # 3-fold cross-validation
                scoring='accuracy'  # Optimize for accuracy
            )

            # Train the model with all hyperparameter combinations
            parameter_search.fit(training_features, training_labels)

            # Get the best model from the search
            optimized_model = parameter_search.best_estimator_

            # Evaluate the model on test data
            predictions = optimized_model.predict(test_features)

            # Calculate performance metrics
            accuracy = accuracy_score(test_labels, predictions)
            precision = precision_score(test_labels, predictions)
            recall = recall_score(test_labels, predictions)
            f1 = f1_score(test_labels, predictions)
            detailed_report = classification_report(test_labels, predictions)

            return (
                optimized_model,
                parameter_search.best_params_,
                accuracy,
                precision,
                recall,
                f1,
                detailed_report
            )

        except Exception as error:
            messagebox.showerror(
                "Training Error",
                f"Something went wrong during model training:\n{error}"
            )
            return None, None, 0, 0, 0, 0, ""


class SpamDetectionApp:
    """User interface for the spam detection application."""

    def __init__(self, root):
        """
        Initialize the application user interface.

        Args:
            root: Root Tkinter window
        """
        self.root = root
        self.root.title("SMS Spam Shield")
        self.root.geometry("650x500")

        # Initialize the spam detection system
        self.spam_system = SpamDetectionSystem()

        # Create the user interface
        self.create_interface()

    def create_interface(self):
        """Create the application's user interface elements."""
        # Application title
        title_label = tk.Label(
            self.root,
            text="SMS Spam Shield",
            font=("Arial", 16, "bold")
        )
        title_label.pack(pady=15)

        # Dataset selection section
        dataset_frame = tk.LabelFrame(self.root, text="Step 1: Load Your Dataset", padx=10, pady=10)
        dataset_frame.pack(fill="x", padx=20, pady=5)

        load_button = tk.Button(
            dataset_frame,
            text="Select Dataset File",
            command=self.load_training_data,
            width=20
        )
        load_button.pack(pady=5)

        # Model selection section
        model_frame = tk.LabelFrame(self.root, text="Step 2: Select and Train Model", padx=10, pady=10)
        model_frame.pack(fill="x", padx=20, pady=5)

        self.model_choice = tk.StringVar(value="Logistic Regression")
        tk.Radiobutton(
            model_frame,
            text="Logistic Regression (Faster)",
            variable=self.model_choice,
            value="Logistic Regression"
        ).pack(anchor="w")

        tk.Radiobutton(
            model_frame,
            text="Random Forest (More Accurate)",
            variable=self.model_choice,
            value="Random Forest"
        ).pack(anchor="w")

        train_button = tk.Button(
            model_frame,
            text="Train Spam Detector",
            command=self.train_spam_model,
            width=20
        )
        train_button.pack(pady=10)

        # Message testing section
        message_frame = tk.LabelFrame(self.root, text="Step 3: Check Messages for Spam", padx=10, pady=10)
        message_frame.pack(fill="x", padx=20, pady=5)

        tk.Label(message_frame, text="Enter a message to analyze:").pack(anchor="w")

        self.message_entry = tk.Text(message_frame, width=60, height=4)
        self.message_entry.pack(pady=5, fill="x")

        check_button = tk.Button(
            message_frame,
            text="Scan for Spam",
            command=self.analyze_message,
            width=20,
            bg="#4CAF50",
            fg="white"
        )
        check_button.pack(pady=10)

        # Status bar
        self.status_label = tk.Label(
            self.root,
            text="Ready to detect spam messages",
            bd=1,
            relief=tk.SUNKEN,
            anchor=tk.W
        )
        self.status_label.pack(side=tk.BOTTOM, fill=tk.X)

    def load_training_data(self):
        """Load and process the spam dataset."""
        file_path = filedialog.askopenfilename(
            title="Open Spam Dataset",
            filetypes=[("TSV Files", "*.tsv"), ("All Files", "*.*")]
        )

        if not file_path:
            return

        try:
            # Load the dataset (tab-separated values)
            raw_dataset = pd.read_csv(
                file_path,
                sep='\t',
                header=None,
                names=["label", "message"]
            )

            # Clean and preprocess the dataset
            self.spam_system.dataset = self.spam_system.clean_dataset(raw_dataset)

            # Update status
            dataset_size = len(self.spam_system.dataset)
            spam_count = sum(self.spam_system.dataset['label'])
            ham_count = dataset_size - spam_count

            messagebox.showinfo(
                "Dataset Loaded",
                f"Successfully loaded {dataset_size} messages:\n"
                f"• {spam_count} spam messages ({spam_count / dataset_size:.1%})\n"
                f"• {ham_count} legitimate messages ({ham_count / dataset_size:.1%})"
            )

            self.status_label.config(text=f"Dataset loaded: {dataset_size} messages")

        except Exception as error:
            messagebox.showerror(
                "Dataset Error",
                f"Could not load the dataset:\n{error}"
            )

    def train_spam_model(self):
        """Train and evaluate the spam detection model."""
        if self.spam_system.dataset is None:
            messagebox.showwarning(
                "No Dataset",
                "Please load a dataset before training the model."
            )
            return

        # Extract features from message text
        features, self.spam_system.vectorizer = self.spam_system.create_text_features(self.spam_system.dataset)
        labels = self.spam_system.dataset['label']

        # Split data into training and testing sets
        training_features, test_features, training_labels, test_labels = train_test_split(
            features, labels, test_size=0.2, random_state=42
        )

        # Get the selected model type
        model_type = self.model_choice.get()

        # Train and evaluate the model
        results = self.spam_system.build_optimized_model(
            training_features, test_features, training_labels, test_labels, model_type
        )

        self.spam_system.trained_model, self.spam_system.model_parameters, accuracy, precision, recall, f1, _ = results

        if self.spam_system.trained_model:
            # Display model performance with human-friendly metrics
            messagebox.showinfo(
                "Training Complete",
                f"Your {model_type} model is ready!\n\n"
                f"Performance Metrics:\n"
                f"• Accuracy: {accuracy:.1%}\n"
                f"• Precision: {precision:.1%}\n"
                f"• Recall: {recall:.1%}\n"
                f"• F1 Score: {f1:.1%}\n\n"
                f"Best parameters: {self.spam_system.model_parameters}"
            )

            self.status_label.config(text=f"Model trained with {accuracy:.1%} accuracy")
        else:
            messagebox.showerror("Training Failed", "Could not train the spam detection model.")

    def analyze_message(self):
        """Analyze a message to determine if it's spam."""
        if not self.spam_system.trained_model or not self.spam_system.vectorizer:
            messagebox.showwarning(
                "Model Not Ready",
                "Please train a model before analyzing messages."
            )
            return

        # Get the message text from the input field
        message_text = self.message_entry.get("1.0", tk.END).strip()

        if not message_text:
            messagebox.showwarning("Empty Message", "Please enter a message to analyze.")
            return

        # Convert the message to features using the same vectorizer
        message_features = self.spam_system.vectorizer.transform([message_text]).toarray()

        # Make a prediction
        prediction = self.spam_system.trained_model.predict(message_features)

        if prediction[0] == 1:
            # Spam detected
            self.status_label.config(text="SPAM DETECTED! Alert sent via WhatsApp.", fg="red")

            result_message = (
                "🚨 SPAM DETECTED! 🚨\n\n"
                "This message has been identified as spam.\n"
                "A WhatsApp alert has been sent."
            )

            # Send WhatsApp alert
            self.spam_system.send_spam_alert(message_text)
        else:
            # Not spam
            self.status_label.config(text="Message appears to be legitimate.", fg="green")

            result_message = (
                "✅ LEGITIMATE MESSAGE\n\n"
                "This message appears to be safe."
            )

        messagebox.showinfo("Analysis Result", result_message)


# Launch the application
if __name__ == "__main__":
    root = tk.Tk()
    app = SpamDetectionApp(root)
    root.mainloop()